package com.example.mylibrary;

import java.util.ArrayList;

public class Utils {
    private static Utils instance;
    private static ArrayList<Book> allBooks;
    private static ArrayList<Book> alreadyReadBooks;
    private static ArrayList<Book> currentlyReadingBooks;
    private static ArrayList<Book> WantToReadBooks;
    private static ArrayList<Book> favoriteBooks;

    public Utils() {
        if (null == allBooks) {
            allBooks = new ArrayList<>();
            initData();
        }

        if (null == alreadyReadBooks) {
            alreadyReadBooks = new ArrayList<>();
        }
        if (null == currentlyReadingBooks) {
            currentlyReadingBooks = new ArrayList<>();
        }
        if (null == favoriteBooks) {
            favoriteBooks = new ArrayList<>();

        } if (null == WantToReadBooks) {
            WantToReadBooks = new ArrayList<>();
        }

    }


    public void initData() {
        // TODO: add initial data
        allBooks.add(new Book(1, "Hujan", "Tere Liye", 150, "https://cdn.gramedia.com/uploads/items/9786020324784_Hujan-Cover-Baru-2018.jpg", "A Book about love,life, promise", "Long Description"));
        allBooks.add(new Book(2, "Ada Apa Dengan Cinta?", "Silvarani", 150, "https://i.gr-assets.com/images/S/compressed.photo.goodreads.com/books/1460437528l/29893408._SX318_.jpg", "A Book about love,life, promise", "Long Description"));
    }


    public static synchronized Utils getInstance() {
        if (null == instance) {
            instance = new Utils();
        }
        return instance;
    }
    public static ArrayList<Book> getWantToReadBooks() {
        return WantToReadBooks;
    }
    public static ArrayList<Book> getAllBooks() {
        return allBooks;
    }

    public static ArrayList<Book> getAlreadyReadBooks() {
        return alreadyReadBooks;
    }

    public static ArrayList<Book> getCurrentlyReadingBooks() {
        return currentlyReadingBooks;
    }

    public static ArrayList<Book> getFavoriteBooks() {
        return favoriteBooks;
    }

    public Book getBookById(int id) {
        for (Book b: allBooks) {
            if (b.getId() == id) {
                return b;
            }
        }

        return null;
    }

    public boolean addToAlreadyRead(Book book) {
        return alreadyReadBooks.add(book);
    }

    public boolean addToWantToRead(Book book) {
        return WantToReadBooks.add(book);
    }
    public boolean addToCurrentlyReadingBooks(Book book) {
        return currentlyReadingBooks.add(book);
    }
    public boolean addToFavoritebooks(Book book) {
        return favoriteBooks.add(book);
    }

    // Remove method
    public boolean removeFromAlreadyRead(Book book) {

        return alreadyReadBooks.remove(book);
    }
    public boolean removeFromWantToRead(Book book) {

        return WantToReadBooks.remove(book);
    }
    public boolean removeFromCurrentlyReading(Book book) {

        return currentlyReadingBooks.remove(book);

    }
    public boolean removeFromFavorites(Book book) {

        return favoriteBooks.remove(book);
    }


}
